KADA-5mins production static bundle

Deploy the CONTENTS of this folder to Cloudflare Pages using Direct Upload, or use this folder as the build output directory.

This is a static production bundle: index.html includes the CSS and JavaScript; favicon.svg is separate. No build step is required for direct upload.

For Git-based builds, use the source project with npm install and npm run build, output directory dist/.
