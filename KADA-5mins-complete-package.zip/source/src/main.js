import './style.css';

const app = document.querySelector('#app');
app.innerHTML = `
  <header class="wrap nav">
    <a class="brand" href="#start" aria-label="KADA-5mins home"><span class="mark">K5</span><span>KADA-5mins</span></a>
    <nav class="navlinks" aria-label="Main navigation"><a href="#start">Start here</a><a href="#tools">Tools</a><a href="#about">About</a></nav>
    <a class="btn" href="#timer">Start a sprint ↗</a>
  </header>
  <main>
    <section class="wrap hero" id="start">
      <div>
        <span class="pill">✦ A little progress, every day</span>
        <div class="eyebrow intro-label">YOUR FIVE-MINUTE SPACE</div>
        <h1>Big things start<br>with <em>five minutes.</em></h1>
        <p class="lead">KADA-5mins is your simple space to focus, reset, and get one small thing done. No pressure to finish everything—just start where you are.</p>
        <div class="actions"><a class="btn primary" href="#timer">Start a 5-minute sprint →</a><a class="btn" href="#tools">Explore quick tools</a></div>
        <p class="quote">“Progress counts, even when it’s small.”</p>
      </div>
      <div class="focus-card" id="timer">
        <div class="cardtop"><span><i class="live"></i>FOCUS SESSION</span><span id="timerState">Ready when you are</span></div>
        <div class="timer" id="clock" aria-live="off">05:00</div>
        <div class="timer-label" id="timerLabel">Choose one thing. Give it five minutes.</div>
        <div class="progress" role="progressbar" aria-label="Session progress" aria-valuemin="0" aria-valuemax="300" aria-valuenow="0"><span id="bar"></span></div>
        <div class="timerbuttons"><button class="btn primary" id="startBtn" type="button">▶ Start</button><button class="btn" id="resetBtn" type="button">↺ Reset</button></div>
        <p class="small cardnote">The timer runs in this browser tab. Nothing is sent to a server.</p>
      </div>
    </section>
    <section class="wrap section" id="tools">
      <div class="sectionhead"><div><div class="eyebrow">MAKE IT COUNT</div><h2>What can you do in five minutes?</h2><p>Pick a tiny task. Let the first step be enough.</p></div></div>
      <div class="grid">
        <article class="tile"><div class="tileicon" aria-hidden="true">✎</div><h3>Clear your head</h3><p>Write down what’s on your mind, then choose the one thing that matters next.</p><button class="btn tileAction" data-task="Write a quick brain-dump" type="button">Try this →</button></article>
        <article class="tile"><div class="tileicon" aria-hidden="true">◎</div><h3>Reset your space</h3><p>Put away a few things, clear your desk, or make your next task easier to begin.</p><button class="btn tileAction" data-task="Reset one small part of your space" type="button">Try this →</button></article>
        <article class="tile"><div class="tileicon" aria-hidden="true">↗</div><h3>Move one step forward</h3><p>Send that message, open the document, or tackle the smallest piece of a big goal.</p><button class="btn tileAction" data-task="Take one small step on an important goal" type="button">Try this →</button></article>
      </div>
    </section>
    <section class="wrap section" id="about">
      <div class="sectionhead"><div><div class="eyebrow">A FRESH START</div><h2>Make the next five minutes yours.</h2><p>Set an intention below and use it as your focus for the next sprint.</p></div></div>
      <form class="quickform" id="intentForm"><label class="sr-only" for="intent">Your five-minute intention</label><input id="intent" maxlength="120" placeholder="e.g. Review one page of notes" required><button class="btn primary" type="submit">Set intention</button></form>
      <p class="note">Your intention is only kept in this page session; it is not uploaded or saved to an account.</p>
      <div class="quote" id="intentResult" role="status" aria-live="polite"></div>
    </section>
  </main>
  <footer class="wrap footer"><span>© <span id="year"></span> KADA-5mins</span><span>Built for small steps and fresh starts.</span><a href="#start">Back to top ↑</a></footer>
  <div class="toast" id="toast" role="status" aria-live="polite"></div>
`;

const $ = (selector) => document.querySelector(selector);
let remaining = 300;
let started = false;
let paused = true;
let interval = null;
let toastTimer = null;

function renderTimer() {
  $('#clock').textContent = `${String(Math.floor(remaining / 60)).padStart(2, '0')}:${String(remaining % 60).padStart(2, '0')}`;
  $('#bar').style.width = `${((300 - remaining) / 300) * 100}%`;
  $('.progress').setAttribute('aria-valuenow', String(300 - remaining));
}
function stopTimer() {
  if (interval !== null) window.clearInterval(interval);
  interval = null;
}
function showToast(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  if (toastTimer !== null) window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove('show'), 2600);
}
function finishTimer() {
  stopTimer(); paused = true; started = false;
  $('#startBtn').textContent = '▶ Start again';
  $('#timerState').textContent = 'Session complete';
  $('#timerLabel').textContent = 'You showed up. That counts.';
  showToast('Five minutes complete — well done!');
}
function tick() {
  if (remaining > 0) remaining -= 1;
  renderTimer();
  if (remaining === 0) finishTimer();
}
$('#startBtn').addEventListener('click', () => {
  if (!paused) {
    paused = true; stopTimer();
    $('#startBtn').textContent = '▶ Resume';
    $('#timerState').textContent = 'Paused';
    $('#timerLabel').textContent = 'Take a breath. Resume when ready.';
    return;
  }
  if (!started) { started = true; remaining = 300; renderTimer(); }
  paused = false;
  $('#timerState').textContent = 'You’ve got this';
  $('#timerLabel').textContent = 'One thing at a time.';
  $('#startBtn').textContent = 'Ⅱ Pause';
  stopTimer(); interval = window.setInterval(tick, 1000);
});
$('#resetBtn').addEventListener('click', () => {
  stopTimer(); remaining = 300; started = false; paused = true;
  $('#startBtn').textContent = '▶ Start';
  $('#timerState').textContent = 'Ready when you are';
  $('#timerLabel').textContent = 'Choose one thing. Give it five minutes.';
  renderTimer();
});
document.querySelectorAll('.tileAction').forEach((button) => {
  button.addEventListener('click', () => {
    $('#intent').value = button.dataset.task;
    $('#intentResult').textContent = '';
    $('#intent').focus();
    $('#about').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
});
$('#intentForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const value = $('#intent').value.trim();
  if (!value) return;
  $('#intentResult').textContent = `Your focus: ${value}`;
  $('#timerLabel').textContent = `Focus on: ${value}`;
  showToast('Intention set. Start your sprint when ready.');
});
$('#year').textContent = String(new Date().getFullYear());
renderTimer();
