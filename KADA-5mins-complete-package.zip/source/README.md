# KADA-5mins

Responsive landing page for KADA-5mins, built with Vite. It includes an in-browser five-minute focus timer, selectable quick-task prompts, and a private intention form. User-entered intentions are not sent to a server.

## Requirements
- Node.js 20+ recommended
- npm

## Run locally
```bash
npm install
npm run dev
```

## Production build
```bash
npm run build
```

Output is written to `dist/` for Cloudflare Pages.

## Cloudflare Pages settings
- Project name: `kada-5mins`
- Build command: `npm run build`
- Build output directory: `dist`
- Root directory: `/`

## Deployment status
The Cloudflare Pages project was created, but a production deployment must still be triggered through Git integration or the Cloudflare Pages deployment workflow. No live deployment is implied by this source package.
